# Add project specific ProGuard rules here.
-keep class com.mdultd.duo.data.** { *; }
-dontwarn org.conscrypt.**
