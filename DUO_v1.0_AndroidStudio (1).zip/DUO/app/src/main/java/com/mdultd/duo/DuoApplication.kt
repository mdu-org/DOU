package com.mdultd.duo

import android.app.Application
import android.util.Log
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.google.android.gms.ads.MobileAds
import com.google.firebase.FirebaseApp
import com.mdultd.duo.download.AutoSaveWorker
import java.util.concurrent.TimeUnit

class DuoApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        try {
            FirebaseApp.initializeApp(this)
        } catch (e: Exception) {
            Log.w("DuoApplication", "Firebase init failed (check google-services.json)", e)
        }
        try {
            MobileAds.initialize(this) { status ->
                Log.d("DuoApplication", "AdMob init status: ${status.adapterStatusMap}")
            }
        } catch (e: Exception) {
            Log.w("DuoApplication", "AdMob init failed", e)
        }
        scheduleAutoSave()
    }

    /** AutoSave feature: periodically checks clipboard for new links while on WiFi. */
    private fun scheduleAutoSave() {
        try {
            val constraints = androidx.work.Constraints.Builder()
                .setRequiredNetworkType(NetworkType.UNMETERED)
                .build()

            val request = PeriodicWorkRequestBuilder<AutoSaveWorker>(15, TimeUnit.MINUTES)
                .setConstraints(constraints)
                .build()

            WorkManager.getInstance(this).enqueueUniquePeriodicWork(
                "duo_auto_save",
                ExistingPeriodicWorkPolicy.KEEP,
                request
            )
        } catch (e: Exception) {
            Log.w("DuoApplication", "Failed to schedule AutoSave", e)
        }
    }
}
