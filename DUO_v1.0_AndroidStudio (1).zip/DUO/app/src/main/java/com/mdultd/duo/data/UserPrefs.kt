package com.mdultd.duo.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "duo_prefs")

/**
 * Central place for lightweight persisted user preferences: onboarding
 * completion flag, dark/light theme choice, and lifetime "data saved"
 * counter shown in Settings.
 */
class UserPrefs(private val context: Context) {

    private object Keys {
        val HAS_SEEN_ONBOARDING = booleanPreferencesKey("has_seen_onboarding")
        val IS_DARK_THEME = booleanPreferencesKey("is_dark_theme")
        val DATA_SAVED_BYTES = longPreferencesKey("data_saved_bytes")
        val LAST_CLIPBOARD_HASH = stringPreferencesKey("last_clipboard_hash")
    }

    val hasSeenOnboarding: Flow<Boolean> = context.dataStore.data
        .catch { emit(emptyPreferences()) }
        .map { it[Keys.HAS_SEEN_ONBOARDING] ?: false }

    val isDarkTheme: Flow<Boolean> = context.dataStore.data
        .catch { emit(emptyPreferences()) }
        .map { it[Keys.IS_DARK_THEME] ?: true }

    val dataSavedBytes: Flow<Long> = context.dataStore.data
        .catch { emit(emptyPreferences()) }
        .map { it[Keys.DATA_SAVED_BYTES] ?: 0L }

    suspend fun setHasSeenOnboarding(seen: Boolean) {
        context.dataStore.edit { it[Keys.HAS_SEEN_ONBOARDING] = seen }
    }

    suspend fun setDarkTheme(dark: Boolean) {
        context.dataStore.edit { it[Keys.IS_DARK_THEME] = dark }
    }

    suspend fun addDataSaved(bytes: Long) {
        context.dataStore.edit { prefs ->
            val current = prefs[Keys.DATA_SAVED_BYTES] ?: 0L
            prefs[Keys.DATA_SAVED_BYTES] = current + bytes
        }
    }

    suspend fun getLastClipboardHash(): String? =
        context.dataStore.data
            .catch { emit(emptyPreferences()) }
            .map { it[Keys.LAST_CLIPBOARD_HASH] }
            .first()

    suspend fun setLastClipboardHash(hash: String) {
        context.dataStore.edit { it[Keys.LAST_CLIPBOARD_HASH] = hash }
    }
}
