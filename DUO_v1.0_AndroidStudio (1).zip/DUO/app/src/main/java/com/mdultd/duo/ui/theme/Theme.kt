package com.mdultd.duo.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val DuoDarkScheme = darkColorScheme(
    primary = RoyalPurple,
    secondary = ElectricCyan,
    tertiary = Gold,
    background = DeepSpace,
    surface = DeepSpace,
    onPrimary = TextPrimary,
    onSecondary = DeepSpace,
    onBackground = TextPrimary,
    onSurface = TextPrimary,
    error = ErrorRed
)

private val DuoLightScheme = lightColorScheme(
    primary = RoyalPurple,
    secondary = ElectricCyan,
    tertiary = Gold,
    background = Color(0xFFF4F4FA),
    surface = Color(0xFFFFFFFF),
    onPrimary = Color.White,
    onBackground = Color(0xFF10101A),
    onSurface = Color(0xFF10101A)
)

@Composable
fun DuoTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DuoDarkScheme else DuoLightScheme
    val view = LocalView.current

    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window ?: return@SideEffect
            window.statusBarColor = colorScheme.background.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars =
                !darkTheme && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = DuoTypography,
        content = content
    )
}
