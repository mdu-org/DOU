package com.mdultd.duo.download

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.util.Log
import androidx.core.content.getSystemService
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.mdultd.duo.data.AppDatabase
import com.mdultd.duo.data.DownloadStatus
import com.mdultd.duo.data.SavedItem
import com.mdultd.duo.data.SavedItemDao
import com.mdultd.duo.data.UserPrefs
import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeoutOrNull

/**
 * DUO SAVE core worker. Takes a shared URL, saves a PENDING SavedItem row,
 * then delegates the actual byte transfer to Android's system
 * DownloadManager (resumable, works in the background even if DUO is
 * killed). Polls DownloadManager for completion and updates Room + the
 * "data saved" counter in Settings.
 */
class DownloadWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    companion object {
        const val KEY_URL = "key_url"
        const val KEY_SOURCE_APP = "key_source_app"
        private const val TAG = "DownloadWorker"
        private const val POLL_INTERVAL_MS = 1500L
        private const val TIMEOUT_MS = 5 * 60 * 1000L // 5 minutes
    }

    override suspend fun doWork(): Result {
        val url = inputData.getString(KEY_URL) ?: return Result.failure()
        val sourceApp = inputData.getString(KEY_SOURCE_APP) ?: "Shared Link"

        val db = AppDatabase.getInstance(applicationContext)
        val dao = db.savedItemDao()

        val fileName = guessFileName(url)
        val mimeType = guessMimeType(url)

        val savedItemId = try {
            dao.insert(
                SavedItem(
                    title = fileName,
                    sourceUrl = url,
                    localFilePath = null,
                    sourceApp = sourceApp,
                    mimeType = mimeType,
                    status = DownloadStatus.PENDING
                )
            )
        } catch (e: Exception) {
            Log.e(TAG, "Failed to insert SavedItem", e)
            return Result.failure()
        }

        return try {
            val downloadManager = applicationContext.getSystemService<DownloadManager>()
                ?: return markFailed(dao, savedItemId)

            val request = DownloadManager.Request(Uri.parse(url))
                .setTitle(fileName)
                .setDescription("Downloading via DUO Save")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_ONLY_COMPLETION)
                .setDestinationInExternalFilesDir(
                    applicationContext,
                    Environment.DIRECTORY_DOWNLOADS,
                    "DUO/$fileName"
                )
                .setAllowedOverMetered(true)
                .setAllowedOverRoaming(true)

            dao.getById(savedItemId)?.let { dao.update(it.copy(status = DownloadStatus.DOWNLOADING)) }

            val downloadId = downloadManager.enqueue(request)
            val completed = withTimeoutOrNull(TIMEOUT_MS) {
                pollUntilComplete(downloadManager, downloadId)
            }

            if (completed == true) {
                val localUri = downloadManager.getUriForDownloadedFile(downloadId)
                val sizeBytes = queryFileSize(downloadManager, downloadId)

                dao.getById(savedItemId)?.let {
                    dao.update(
                        it.copy(
                            status = DownloadStatus.COMPLETE,
                            localFilePath = localUri?.toString(),
                            sizeBytes = sizeBytes
                        )
                    )
                }

                UserPrefs(applicationContext).addDataSaved(sizeBytes)
                Result.success()
            } else {
                markFailed(dao, savedItemId)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Download failed for $url", e)
            markFailed(dao, savedItemId)
        }
    }

    private suspend fun markFailed(dao: SavedItemDao, id: Long): Result {
        return try {
            dao.getById(id)?.let { dao.update(it.copy(status = DownloadStatus.FAILED)) }
            Result.failure()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to mark item failed", e)
            Result.failure()
        }
    }

    private suspend fun pollUntilComplete(downloadManager: DownloadManager, downloadId: Long): Boolean {
        while (true) {
            val query = DownloadManager.Query().setFilterById(downloadId)
            downloadManager.query(query)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val statusIndex = cursor.getColumnIndex(DownloadManager.COLUMN_STATUS)
                    if (statusIndex >= 0) {
                        when (cursor.getInt(statusIndex)) {
                            DownloadManager.STATUS_SUCCESSFUL -> return true
                            DownloadManager.STATUS_FAILED -> return false
                        }
                    }
                }
            }
            delay(POLL_INTERVAL_MS)
        }
    }

    private fun queryFileSize(downloadManager: DownloadManager, downloadId: Long): Long {
        return try {
            val query = DownloadManager.Query().setFilterById(downloadId)
            downloadManager.query(query)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val bytesIndex = cursor.getColumnIndex(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)
                    if (bytesIndex >= 0) return cursor.getLong(bytesIndex)
                }
            }
            0L
        } catch (e: Exception) {
            0L
        }
    }

    private fun guessFileName(url: String): String {
        return try {
            val lastSegment = Uri.parse(url).lastPathSegment
            if (!lastSegment.isNullOrBlank()) lastSegment else "duo_save_${System.currentTimeMillis()}"
        } catch (e: Exception) {
            "duo_save_${System.currentTimeMillis()}"
        }
    }

    private fun guessMimeType(url: String): String {
        val lower = url.lowercase()
        return when {
            lower.endsWith(".mp4") || lower.contains("youtube") -> "video/mp4"
            lower.endsWith(".mp3") -> "audio/mpeg"
            lower.endsWith(".jpg") || lower.endsWith(".jpeg") -> "image/jpeg"
            lower.endsWith(".png") -> "image/png"
            lower.endsWith(".pdf") -> "application/pdf"
            else -> "text/html"
        }
    }
}
