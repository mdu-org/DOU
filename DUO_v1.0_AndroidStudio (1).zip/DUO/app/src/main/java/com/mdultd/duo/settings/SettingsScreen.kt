package com.mdultd.duo.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.mdultd.duo.data.AppDatabase
import com.mdultd.duo.data.UserPrefs
import com.mdultd.duo.ui.theme.DeepSpace
import com.mdultd.duo.ui.theme.ElectricCyan
import com.mdultd.duo.ui.theme.GlassCard
import com.mdultd.duo.ui.theme.Gold
import com.mdultd.duo.ui.theme.RoyalPurple
import com.mdultd.duo.ui.theme.TextSecondary
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.ln
import kotlin.math.pow

@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val userPrefs = remember { UserPrefs(context) }
    val db = remember { AppDatabase.getInstance(context) }
    val scope = rememberCoroutineScope()

    val isDarkTheme by userPrefs.isDarkTheme.collectAsState(initial = true)
    val dataSavedBytes by db.savedItemDao().getTotalBytesSaved().collectAsState(initial = 0L)
    val itemsSavedCount by db.savedItemDao().getCompletedCount().collectAsState(initial = 0)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(DeepSpace, RoyalPurple.copy(alpha = 0.08f), DeepSpace)))
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
            }
            Text("Settings", style = MaterialTheme.typography.titleLarge)
        }

        Spacer(Modifier.height(16.dp))

        GlassCard {
            Column(modifier = Modifier.padding(20.dp)) {
                Text("Data Saved", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                Text(
                    formatBytes(dataSavedBytes),
                    style = MaterialTheme.typography.headlineMedium,
                    color = ElectricCyan
                )
                Text(
                    "$itemsSavedCount item${if (itemsSavedCount == 1) "" else "s"} saved offline",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
            }
        }

        Spacer(Modifier.height(12.dp))

        GlassCard {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Dark Theme", style = MaterialTheme.typography.bodyLarge)
                    Text(
                        "DUO's glassmorphism looks best in the dark",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary
                    )
                }
                Switch(
                    checked = isDarkTheme,
                    onCheckedChange = { checked ->
                        scope.launch { userPrefs.setDarkTheme(checked) }
                    },
                    colors = SwitchDefaults.colors(checkedTrackColor = RoyalPurple)
                )
            }
        }

        Spacer(Modifier.height(12.dp))

        GlassCard {
            Column(modifier = Modifier.padding(20.dp)) {
                Text("About", style = MaterialTheme.typography.bodyLarge)
                Spacer(Modifier.height(4.dp))
                Text(
                    "DUO — Offline Internet\nA product by MDU LTD",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
            }
        }

        Spacer(Modifier.weight(1f))

        Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Text(
                "© 2026 MDU LTD",
                style = MaterialTheme.typography.labelSmall,
                color = Gold
            )
        }
        Spacer(Modifier.height(8.dp))
    }
}

/** Formats a byte count as a human-readable string, e.g. "12.4 MB". */
private fun formatBytes(bytes: Long): String {
    if (bytes <= 0) return "0 B"
    val units = arrayOf("B", "KB", "MB", "GB", "TB")
    val digitGroups = (ln(bytes.toDouble()) / ln(1024.0)).toInt().coerceIn(0, units.lastIndex)
    val value = bytes / 1024.0.pow(digitGroups.toDouble())
    return String.format(Locale.US, "%.1f %s", value, units[digitGroups])
}
