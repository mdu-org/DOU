package com.mdultd.duo.onboarding

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.airbnb.lottie.compose.LottieAnimation
import com.airbnb.lottie.compose.LottieCompositionSpec
import com.airbnb.lottie.compose.LottieConstants
import com.airbnb.lottie.compose.animateLottieCompositionAsState
import com.airbnb.lottie.compose.rememberLottieComposition
import com.mdultd.duo.data.UserPrefs
import com.mdultd.duo.split.SplitScreenLauncher
import com.mdultd.duo.ui.theme.DeepSpace
import com.mdultd.duo.ui.theme.ElectricCyan
import com.mdultd.duo.ui.theme.Gold
import com.mdultd.duo.ui.theme.RoyalPurple
import com.mdultd.duo.ui.theme.TextSecondary
import kotlinx.coroutines.launch

private data class OnboardingPage(
    val title: String,
    val subtitle: String,
    val lottieUrl: String,
    val isSplitDemo: Boolean = false
)

private val pages = listOf(
    OnboardingPage(
        title = "Welcome to DUO",
        subtitle = "1 Tap to Do 2 Things. Save the internet.",
        lottieUrl = "https://assets9.lottiefiles.com/packages/lf20_touohxv0.json"
    ),
    OnboardingPage(
        title = "Smart Pairs",
        subtitle = "Chat while you watch. Browse while you navigate. DUO opens two apps together, instantly.",
        lottieUrl = "https://assets2.lottiefiles.com/packages/lf20_kkflmtur.json"
    ),
    OnboardingPage(
        title = "See It In Action",
        subtitle = "Tap below to open WhatsApp + YouTube together, right now.",
        lottieUrl = "",
        isSplitDemo = true
    ),
    OnboardingPage(
        title = "DUO Save",
        subtitle = "Share any link to DUO and it downloads for offline access — no data wasted twice.",
        lottieUrl = "https://assets4.lottiefiles.com/packages/lf20_qm8eqzse.json"
    ),
    OnboardingPage(
        title = "You're All Set",
        subtitle = "Build your own Custom Pairs anytime. Let's save some internet.",
        lottieUrl = "https://assets6.lottiefiles.com/packages/lf20_totrpclr.json"
    )
)

@Composable
fun OnboardingScreen(
    userPrefs: UserPrefs,
    onFinished: () -> Unit
) {
    val pagerState = rememberPagerState(pageCount = { pages.size })
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(listOf(DeepSpace, RoyalPurple.copy(alpha = 0.15f), DeepSpace))
            )
    ) {
        HorizontalPager(
            state = pagerState,
            modifier = Modifier.weight(1f)
        ) { pageIndex ->
            OnboardingPageContent(
                page = pages[pageIndex],
                onLaunchSplitDemo = {
                    SplitScreenLauncher.launchDuo(
                        context = context,
                        packageOne = "com.whatsapp",
                        packageTwo = "com.google.android.youtube"
                    )
                }
            )
        }

        PagerIndicator(pageCount = pages.size, currentPage = pagerState.currentPage)

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            TextButton(onClick = {
                scope.launch {
                    userPrefs.setHasSeenOnboarding(true)
                    onFinished()
                }
            }) {
                Text("Skip", color = TextSecondary)
            }

            Button(
                colors = ButtonDefaults.buttonColors(containerColor = RoyalPurple),
                onClick = {
                    scope.launch {
                        if (pagerState.currentPage < pages.lastIndex) {
                            pagerState.animateScrollToPage(pagerState.currentPage + 1)
                        } else {
                            userPrefs.setHasSeenOnboarding(true)
                            onFinished()
                        }
                    }
                }
            ) {
                Text(if (pagerState.currentPage == pages.lastIndex) "Get Started" else "Next")
            }
        }
    }
}

@Composable
private fun OnboardingPageContent(
    page: OnboardingPage,
    onLaunchSplitDemo: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        if (page.isSplitDemo) {
            SplitDemoVisual()
        } else if (page.lottieUrl.isNotEmpty()) {
            SafeLottie(url = page.lottieUrl)
        }

        Spacer(Modifier.height(32.dp))

        Text(
            text = page.title,
            style = MaterialTheme.typography.headlineMedium,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(12.dp))
        Text(
            text = page.subtitle,
            style = MaterialTheme.typography.bodyLarge,
            color = TextSecondary,
            textAlign = TextAlign.Center
        )

        if (page.isSplitDemo) {
            Spacer(Modifier.height(24.dp))
            Button(
                colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan),
                onClick = onLaunchSplitDemo
            ) {
                Text("Try Split Screen Demo", color = DeepSpace)
            }
        }
    }
}

/**
 * A lightweight animated mock of the split-screen layout (top half
 * WhatsApp-styled, bottom half YouTube-styled) so onboarding screen 3
 * always shows something even before the user taps the real demo button.
 */
@Composable
private fun SplitDemoVisual() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .height(220.dp)
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(Color(0xFF25D366), RoundedCornerShape(16.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text("WhatsApp", color = Color.White)
        }
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(Color(0xFFFF0000), RoundedCornerShape(16.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text("YouTube", color = Color.White)
        }
    }
}

@Composable
private fun SafeLottie(url: String) {
    // Network-hosted Lottie files require internet on first load; if it
    // fails (offline device, bad URL) we simply render nothing instead of
    // crashing, per the "no crashes" rule.
    val composition by rememberLottieComposition(LottieCompositionSpec.Url(url))
    val progress by animateLottieCompositionAsState(
        composition = composition,
        iterations = LottieConstants.IterateForever
    )
    Box(modifier = Modifier.size(220.dp), contentAlignment = Alignment.Center) {
        if (composition != null) {
            LottieAnimation(
                composition = composition,
                progress = { progress },
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}

@Composable
private fun PagerIndicator(pageCount: Int, currentPage: Int) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.Center
    ) {
        repeat(pageCount) { index ->
            val isSelected = index == currentPage
            val width by animateFloatAsState(
                targetValue = if (isSelected) 24f else 8f,
                animationSpec = tween(200, easing = LinearEasing),
                label = "dotWidth"
            )
            Box(
                modifier = Modifier
                    .padding(horizontal = 4.dp)
                    .width(width.dp)
                    .height(8.dp)
                    .background(
                        color = if (isSelected) Gold else TextSecondary.copy(alpha = 0.3f),
                        shape = CircleShape
                    )
            )
        }
    }
}
