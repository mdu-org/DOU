package com.mdultd.duo.custompair

import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.mdultd.duo.data.AppDatabase
import com.mdultd.duo.data.CustomPair
import com.mdultd.duo.ui.theme.DeepSpace
import com.mdultd.duo.ui.theme.ElectricCyan
import com.mdultd.duo.ui.theme.GlassCard
import com.mdultd.duo.ui.theme.RoyalPurple
import com.mdultd.duo.ui.theme.TextSecondary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class InstalledAppInfo(
    val packageName: String,
    val label: String
)

/**
 * Lets the user pick any 2 installed apps to build a Custom Pair, saved
 * to Room so it appears alongside the default Smart Pairs on Home.
 *
 * NOTE: relies on QUERY_ALL_PACKAGES (declared in the manifest) to list
 * every launchable app, since Android 11+ hides most packages by default.
 */
@Composable
fun CustomPairScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val db = remember { AppDatabase.getInstance(context) }

    var apps by remember { mutableStateOf<List<InstalledAppInfo>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var firstPick by remember { mutableStateOf<InstalledAppInfo?>(null) }
    var secondPick by remember { mutableStateOf<InstalledAppInfo?>(null) }

    LaunchedEffect(Unit) {
        apps = withContext(Dispatchers.IO) { loadInstalledApps(context) }
        isLoading = false
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(DeepSpace, RoyalPurple.copy(alpha = 0.08f), DeepSpace)))
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
            }
            Column {
                Text("Build a Custom Pair", style = MaterialTheme.typography.titleLarge)
                Text(
                    text = when {
                        firstPick == null -> "Pick your first app"
                        secondPick == null -> "Now pick the second app"
                        else -> "Pair ready!"
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
            }
        }

        if (firstPick != null || secondPick != null) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                firstPick?.let { PickChip(it.label) { firstPick = null } }
                secondPick?.let { PickChip(it.label) { secondPick = null } }
            }
        }

        if (isLoading) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = ElectricCyan)
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(apps, key = { it.packageName }) { app ->
                    val isSelected = app.packageName == firstPick?.packageName ||
                        app.packageName == secondPick?.packageName

                    AppRow(
                        app = app,
                        isSelected = isSelected,
                        onClick = {
                            when {
                                isSelected -> {
                                    if (firstPick?.packageName == app.packageName) firstPick = null
                                    if (secondPick?.packageName == app.packageName) secondPick = null
                                }
                                firstPick == null -> firstPick = app
                                secondPick == null -> {
                                    secondPick = app
                                    val one = firstPick!!
                                    val two = app
                                    scope.launch {
                                        db.customPairDao().insert(
                                            CustomPair(
                                                appOnePackage = one.packageName,
                                                appOneName = one.label,
                                                appTwoPackage = two.packageName,
                                                appTwoName = two.label
                                            )
                                        )
                                        onBack()
                                    }
                                }
                                else -> { /* Both slots full; ignore extra taps. */ }
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun PickChip(label: String, onRemove: () -> Unit) {
    GlassCard(modifier = Modifier.clickable { onRemove() }) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(label, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
private fun AppRow(app: InstalledAppInfo, isSelected: Boolean, onClick: () -> Unit) {
    GlassCard(modifier = Modifier.clickable { onClick() }) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(app.label, style = MaterialTheme.typography.bodyLarge)
            if (isSelected) {
                Icon(Icons.Filled.Check, contentDescription = "Selected", tint = ElectricCyan)
            }
        }
    }
}

/** Queries the system PackageManager for all launchable, non-DUO apps. */
private fun loadInstalledApps(context: android.content.Context): List<InstalledAppInfo> {
    return try {
        val pm = context.packageManager
        val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val resolved = pm.queryIntentActivities(mainIntent, PackageManager.MATCH_ALL)

        resolved
            .asSequence()
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .distinctBy { it.first }
            .filter { (pkg, _) -> pkg != context.packageName }
            .map { (pkg, label) -> InstalledAppInfo(packageName = pkg, label = label) }
            .sortedBy { it.label.lowercase() }
            .toList()
    } catch (e: Exception) {
        emptyList()
    }
}
