package com.mdultd.duo.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.mdultd.duo.data.SmartPair
import com.mdultd.duo.data.SmartPairsRepo
import com.mdultd.duo.split.SplitScreenLauncher
import com.mdultd.duo.ui.theme.DeepSpace
import com.mdultd.duo.ui.theme.DuoFooter
import com.mdultd.duo.ui.theme.ElectricCyan
import com.mdultd.duo.ui.theme.GlassCard
import com.mdultd.duo.ui.theme.Gold
import com.mdultd.duo.ui.theme.RoyalPurple
import com.mdultd.duo.ui.theme.TextSecondary

@Composable
fun HomeScreen(
    onOpenLibrary: () -> Unit,
    onOpenCustomPair: () -> Unit,
    onOpenSettings: () -> Unit
) {
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(listOf(DeepSpace, RoyalPurple.copy(alpha = 0.08f), DeepSpace))
            )
    ) {
        TopBar(onOpenSettings = onOpenSettings)

        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Text("Smart Pairs", style = MaterialTheme.typography.titleLarge)
                Text(
                    "Tap a card to open both apps together.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
                Spacer(Modifier.height(4.dp))
            }

            items(SmartPairsRepo.defaultPairs) { pair ->
                SmartPairCard(
                    pair = pair,
                    onClick = {
                        if (!pair.isSponsored) {
                            SplitScreenLauncher.launchDuo(
                                context = context,
                                packageOne = pair.appOnePackage,
                                packageTwo = pair.appTwoPackage
                            )
                        }
                        // Sponsored slot: would deep-link to a partner app
                        // listing / AdMob native ad in production.
                    }
                )
            }

            item {
                Spacer(Modifier.height(8.dp))
                CustomPairEntryCard(onClick = onOpenCustomPair)
            }

            item {
                Spacer(Modifier.height(8.dp))
                LibraryEntryCard(onClick = onOpenLibrary)
            }

            item {
                Spacer(Modifier.height(20.dp))
                Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    DuoFooter()
                }
                Spacer(Modifier.height(8.dp))
            }
        }

        // AdMob banner pinned at the bottom of the Home screen.
        AdMobBanner()
    }
}

@Composable
private fun TopBar(onOpenSettings: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 16.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text("DUO", style = MaterialTheme.typography.headlineMedium, color = ElectricCyan)
            Text(
                "1 Tap to Do 2 Things. Save the internet.",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )
        }
        IconButton(onClick = onOpenSettings) {
            Icon(Icons.Filled.Settings, contentDescription = "Settings")
        }
    }
}

@Composable
private fun SmartPairCard(pair: SmartPair, onClick: () -> Unit) {
    GlassCard(modifier = Modifier.clickable { onClick() }) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                if (pair.isSponsored) {
                    Text("SPONSORED", style = MaterialTheme.typography.labelSmall, color = Gold)
                    Text(pair.sponsoredMessage ?: "Discover a partner app", style = MaterialTheme.typography.titleLarge)
                } else {
                    Text("${pair.appOneLabel} + ${pair.appTwoLabel}", style = MaterialTheme.typography.titleLarge)
                    Text("Open both in split screen", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                }
            }
            Icon(
                imageVector = Icons.Filled.Star,
                contentDescription = null,
                tint = if (pair.isSponsored) Gold else ElectricCyan
            )
        }
    }
}

@Composable
private fun CustomPairEntryCard(onClick: () -> Unit) {
    GlassCard(modifier = Modifier.clickable { onClick() }) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text("Build a Custom Pair", style = MaterialTheme.typography.titleLarge)
                Text("Pick any 2 installed apps", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
            }
            Text("+", style = MaterialTheme.typography.headlineMedium, color = RoyalPurple)
        }
    }
}

@Composable
private fun LibraryEntryCard(onClick: () -> Unit) {
    GlassCard(modifier = Modifier.clickable { onClick() }) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text("My Library", style = MaterialTheme.typography.titleLarge)
                Text(
                    "Everything you saved with DUO Save — 100% offline",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
            }
            Icon(Icons.Filled.FolderOpen, contentDescription = null, tint = ElectricCyan)
        }
    }
}
