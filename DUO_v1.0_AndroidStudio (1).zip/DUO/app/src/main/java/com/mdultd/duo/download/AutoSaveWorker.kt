package com.mdultd.duo.download

import android.content.ClipboardManager
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.util.Log
import android.util.Patterns
import androidx.core.content.getSystemService
import androidx.work.CoroutineWorker
import androidx.work.Data
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.mdultd.duo.data.UserPrefs
import java.security.MessageDigest

/**
 * "AutoSave": if the device is on WiFi, checks the clipboard for a link and,
 * if it's new (not previously saved), enqueues a DownloadWorker for it.
 * DUO never auto-saves the same clipboard content twice, and only ever over
 * WiFi, to respect the "save the internet" / no-data-waste promise.
 *
 * Schedule this periodically (e.g. every 15 minutes) via WorkManager's
 * PeriodicWorkRequest from DuoApplication.onCreate().
 */
class AutoSaveWorker(
    private val appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        return try {
            if (!isOnWifi()) return Result.success() // silently skip, not a failure

            val clipUrl = readClipboardUrl() ?: return Result.success()

            val prefs = UserPrefs(applicationContext)
            val hash = sha256(clipUrl)
            val lastHash = prefs.getLastClipboardHash()

            if (hash == lastHash) {
                return Result.success() // already processed this exact clipboard content
            }

            prefs.setLastClipboardHash(hash)

            val inputData = Data.Builder()
                .putString(DownloadWorker.KEY_URL, clipUrl)
                .putString(DownloadWorker.KEY_SOURCE_APP, "AutoSave (Clipboard)")
                .build()

            val request = OneTimeWorkRequestBuilder<DownloadWorker>()
                .setInputData(inputData)
                .build()

            WorkManager.getInstance(applicationContext).enqueue(request)
            Result.success()
        } catch (e: Exception) {
            Log.e("AutoSaveWorker", "AutoSave check failed", e)
            // Never let a background clipboard check crash the app.
            Result.success()
        }
    }

    private fun isOnWifi(): Boolean {
        val cm = appContext.getSystemService<ConnectivityManager>() ?: return false
        val network = cm.activeNetwork ?: return false
        val capabilities = cm.getNetworkCapabilities(network) ?: return false
        return capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
    }

    private fun readClipboardUrl(): String? {
        val clipboard = appContext.getSystemService<ClipboardManager>() ?: return null
        if (!clipboard.hasPrimaryClip()) return null
        val clip = clipboard.primaryClip ?: return null
        if (clip.itemCount == 0) return null

        val text = clip.getItemAt(0).coerceToText(appContext)?.toString() ?: return null
        val matcher = Patterns.WEB_URL.matcher(text)
        return if (matcher.find()) text.substring(matcher.start(), matcher.end()) else null
    }

    private fun sha256(input: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }
}
