package com.mdultd.duo.library

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Downloading
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.HourglassEmpty
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.mdultd.duo.data.AppDatabase
import com.mdultd.duo.data.DownloadStatus
import com.mdultd.duo.data.SavedItem
import com.mdultd.duo.ui.theme.DeepSpace
import com.mdultd.duo.ui.theme.ElectricCyan
import com.mdultd.duo.ui.theme.ErrorRed
import com.mdultd.duo.ui.theme.GlassCard
import com.mdultd.duo.ui.theme.Gold
import com.mdultd.duo.ui.theme.RoyalPurple
import com.mdultd.duo.ui.theme.TextSecondary
import kotlinx.coroutines.launch

/**
 * Shows every item saved via DUO Save, pulled straight from Room, so it
 * works 100% offline (no network call needed to view the library).
 */
@Composable
fun MyLibraryScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val db = remember { AppDatabase.getInstance(context) }
    val scope = rememberCoroutineScope()

    val items by db.savedItemDao().getAll().collectAsState(initial = emptyList())

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(DeepSpace, RoyalPurple.copy(alpha = 0.08f), DeepSpace)))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
            }
            Text("My Library", style = MaterialTheme.typography.titleLarge)
        }

        if (items.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Nothing saved yet", style = MaterialTheme.typography.titleLarge)
                    Text(
                        "Share a link to DUO from any app to save it offline.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary
                    )
                }
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(items, key = { it.id }) { item ->
                    SavedItemCard(
                        item = item,
                        onOpen = { openSavedItem(context, item) },
                        onDelete = {
                            scope.launch { db.savedItemDao().deleteById(item.id) }
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun SavedItemCard(item: SavedItem, onOpen: () -> Unit, onDelete: () -> Unit) {
    GlassCard(modifier = Modifier.clickable(enabled = item.status == DownloadStatus.COMPLETE) { onOpen() }) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                StatusIcon(item.status)
                Column(modifier = Modifier.padding(start = 12.dp)) {
                    Text(item.title, style = MaterialTheme.typography.bodyLarge)
                    Text(
                        "${item.sourceApp} • ${statusLabel(item.status)}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary
                    )
                }
            }
            IconButton(onClick = onDelete) {
                Icon(Icons.Filled.Delete, contentDescription = "Delete", tint = ErrorRed)
            }
        }
    }
}

@Composable
private fun StatusIcon(status: DownloadStatus) {
    when (status) {
        DownloadStatus.COMPLETE -> Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = ElectricCyan)
        DownloadStatus.DOWNLOADING -> Icon(Icons.Filled.Downloading, contentDescription = null, tint = Gold)
        DownloadStatus.PENDING -> Icon(Icons.Filled.HourglassEmpty, contentDescription = null, tint = TextSecondary)
        DownloadStatus.FAILED -> Icon(Icons.Filled.ErrorOutline, contentDescription = null, tint = ErrorRed)
    }
}

private fun statusLabel(status: DownloadStatus): String = when (status) {
    DownloadStatus.COMPLETE -> "Saved offline"
    DownloadStatus.DOWNLOADING -> "Downloading…"
    DownloadStatus.PENDING -> "Queued"
    DownloadStatus.FAILED -> "Failed"
}

private fun openSavedItem(context: android.content.Context, item: SavedItem) {
    try {
        val path = item.localFilePath ?: return
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(Uri.parse(path), item.mimeType)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(intent)
    } catch (e: Exception) {
        // No app can handle this mime type / file is missing — fail silently
        // per the "no crashes" rule rather than throwing.
    }
}
