package com.mdultd.duo.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

// ============================== ENTITIES ==============================

@Entity(tableName = "saved_items")
data class SavedItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val sourceUrl: String,
    val localFilePath: String?,
    val sourceApp: String,          // e.g. "WhatsApp", "YouTube", "Instagram"
    val mimeType: String,
    val sizeBytes: Long = 0,
    val downloadedAt: Long = System.currentTimeMillis(),
    val status: DownloadStatus = DownloadStatus.PENDING
)

enum class DownloadStatus { PENDING, DOWNLOADING, COMPLETE, FAILED }

@Entity(tableName = "custom_pairs")
data class CustomPair(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val appOnePackage: String,
    val appOneName: String,
    val appTwoPackage: String,
    val appTwoName: String,
    val createdAt: Long = System.currentTimeMillis()
)

class Converters {
    @TypeConverter
    fun fromStatus(status: DownloadStatus): String = status.name

    @TypeConverter
    fun toStatus(value: String): DownloadStatus =
        try { DownloadStatus.valueOf(value) } catch (e: IllegalArgumentException) { DownloadStatus.FAILED }
}

// ============================== DAOs ==============================

@Dao
interface SavedItemDao {

    @Query("SELECT * FROM saved_items ORDER BY downloadedAt DESC")
    fun getAll(): Flow<List<SavedItem>>

    @Query("SELECT COUNT(*) FROM saved_items WHERE status = 'COMPLETE'")
    fun getCompletedCount(): Flow<Int>

    @Query("SELECT COALESCE(SUM(sizeBytes), 0) FROM saved_items WHERE status = 'COMPLETE'")
    fun getTotalBytesSaved(): Flow<Long>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: SavedItem): Long

    @Update
    suspend fun update(item: SavedItem)

    @Query("DELETE FROM saved_items WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("SELECT * FROM saved_items WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): SavedItem?
}

@Dao
interface CustomPairDao {

    @Query("SELECT * FROM custom_pairs ORDER BY createdAt DESC")
    fun getAll(): Flow<List<CustomPair>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(pair: CustomPair): Long

    @Query("DELETE FROM custom_pairs WHERE id = :id")
    suspend fun deleteById(id: Long)
}

// ============================== DATABASE ==============================

@Database(
    entities = [SavedItem::class, CustomPair::class],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {

    abstract fun savedItemDao(): SavedItemDao
    abstract fun customPairDao(): CustomPairDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "duo_database"
                )
                    // Safe default for MVP; replace with real migrations before
                    // shipping schema changes to production.
                    .fallbackToDestructiveMigration()
                    .build().also { INSTANCE = it }
            }
        }
    }
}
