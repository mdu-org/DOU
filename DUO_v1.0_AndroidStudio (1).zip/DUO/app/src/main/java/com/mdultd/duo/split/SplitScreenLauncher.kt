package com.mdultd.duo.split

import android.app.Activity
import android.app.ActivityOptions
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.graphics.Rect
import android.os.Build
import android.util.Log
import android.widget.Toast

/**
 * DUO's core "1 Tap to Do 2 Things" mechanic.
 *
 * There is no public API on stock Android for a third-party app to force
 * two arbitrary apps into a split-screen layout (that capability is
 * reserved for the system launcher / System UI). What DUO does instead,
 * without requiring root or system permissions:
 *  1. Launch App One normally.
 *  2. Immediately launch App Two with FLAG_ACTIVITY_LAUNCH_ADJACENT, which
 *     the window manager honors natively on large-screen / foldable /
 *     ChromeOS devices, tiling them side-by-side automatically.
 * On regular phones, App Two opens on top and the user can use Android's
 * native "drag from Recents" gesture to snap both apps into split screen —
 * DUO's onboarding screen 3 demonstrates this exact gesture with a real
 * WhatsApp + YouTube demo.
 */
object SplitScreenLauncher {

    private const val TAG = "SplitScreenLauncher"

    /** Attempts to open [packageOne] and [packageTwo] together. Returns true if both launched. */
    fun launchDuo(context: Context, packageOne: String, packageTwo: String): Boolean {
        val launchedFirst = launchApp(context, packageOne, adjacent = false)
        if (!launchedFirst) {
            Toast.makeText(context, "Couldn't open the first app. Is it installed?", Toast.LENGTH_SHORT).show()
            return false
        }

        val launchedSecond = launchApp(context, packageTwo, adjacent = true)
        if (!launchedSecond) {
            Toast.makeText(context, "Opened the first app, but the second app isn't installed.", Toast.LENGTH_SHORT).show()
            return false
        }
        return true
    }

    private fun launchApp(context: Context, packageName: String, adjacent: Boolean): Boolean {
        return try {
            val pm = context.packageManager
            val launchIntent = pm.getLaunchIntentForPackage(packageName)
                ?: run {
                    Log.w(TAG, "No launch intent for $packageName")
                    return false
                }
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

            val options = ActivityOptions.makeBasic()
            if (adjacent && Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT)
                try {
                    options.launchBounds = Rect(0, 0, 1, 1)
                } catch (e: Exception) {
                    // Not all OEM ROMs honor launchBounds; safe to ignore.
                }
            }

            context.startActivity(launchIntent, options.toBundle())
            true
        } catch (e: ActivityNotFoundException) {
            Log.e(TAG, "Activity not found for $packageName", e)
            false
        } catch (e: Exception) {
            Log.e(TAG, "Failed to launch $packageName", e)
            false
        }
    }

    /** Convenience check used by Home/CustomPair screens before showing a pair as launchable. */
    fun isInstalled(context: Context, packageName: String): Boolean {
        return try {
            context.packageManager.getPackageInfo(packageName, 0)
            true
        } catch (e: Exception) {
            false
        }
    }
}
