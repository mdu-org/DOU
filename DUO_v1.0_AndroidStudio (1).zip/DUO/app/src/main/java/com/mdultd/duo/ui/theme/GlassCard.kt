package com.mdultd.duo.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.unit.dp

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    cornerRadius: Int = 24,
    content: @Composable () -> Unit
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(cornerRadius.dp))
            .background(
                brush = Brush.linearGradient(
                    colors = listOf(GlassWhite, GlassWhite.copy(alpha = 0.05f))
                )
            )
            .border(
                width = 1.dp,
                color = GlassBorder,
                shape = RoundedCornerShape(cornerRadius.dp)
            )
    ) {
        content()
    }
}

/** Standard footer shown across all screens per brand requirements. */
@Composable
fun DuoFooter() {
    androidx.compose.material3.Text(
        text = "© 2026 MDU LTD",
        style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
        color = TextSecondary
    )
}
