package com.mdultd.duo

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.mdultd.duo.custompair.CustomPairScreen
import com.mdultd.duo.data.UserPrefs
import com.mdultd.duo.home.HomeScreen
import com.mdultd.duo.library.MyLibraryScreen
import com.mdultd.duo.onboarding.OnboardingScreen
import com.mdultd.duo.settings.SettingsScreen
import com.mdultd.duo.ui.theme.DuoTheme

/** Route names for DUO's single-activity Navigation Compose graph. */
object DuoRoutes {
    const val ONBOARDING = "onboarding"
    const val HOME = "home"
    const val LIBRARY = "library"
    const val CUSTOM_PAIR = "custom_pair"
    const val SETTINGS = "settings"
}

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val context = LocalContext.current
            val userPrefs = remember { UserPrefs(context) }
            // null == "still loading from DataStore", true/false == known.
            val hasSeenOnboarding by userPrefs.hasSeenOnboarding.collectAsState(initial = null)
            val isDarkTheme by userPrefs.isDarkTheme.collectAsState(initial = true)

            DuoTheme(darkTheme = isDarkTheme) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    hasSeenOnboarding?.let { seen ->
                        DuoNavGraph(userPrefs = userPrefs, startAtOnboarding = !seen)
                    }
                }
            }
        }
    }
}

@Composable
fun DuoNavGraph(userPrefs: UserPrefs, startAtOnboarding: Boolean) {
    val navController: NavHostController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = if (startAtOnboarding) DuoRoutes.ONBOARDING else DuoRoutes.HOME
    ) {
        composable(DuoRoutes.ONBOARDING) {
            OnboardingScreen(
                userPrefs = userPrefs,
                onFinished = {
                    navController.navigate(DuoRoutes.HOME) {
                        popUpTo(DuoRoutes.ONBOARDING) { inclusive = true }
                    }
                }
            )
        }
        composable(DuoRoutes.HOME) {
            HomeScreen(
                onOpenLibrary = { navController.navigate(DuoRoutes.LIBRARY) },
                onOpenCustomPair = { navController.navigate(DuoRoutes.CUSTOM_PAIR) },
                onOpenSettings = { navController.navigate(DuoRoutes.SETTINGS) }
            )
        }
        composable(DuoRoutes.LIBRARY) {
            MyLibraryScreen(onBack = { navController.popBackStack() })
        }
        composable(DuoRoutes.CUSTOM_PAIR) {
            CustomPairScreen(onBack = { navController.popBackStack() })
        }
        composable(DuoRoutes.SETTINGS) {
            SettingsScreen(onBack = { navController.popBackStack() })
        }
    }
}
