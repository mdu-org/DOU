package com.mdultd.duo.ui.theme

import androidx.compose.ui.graphics.Color

// === DUO Brand Palette ===
val DeepSpace = Color(0xFF050510)
val RoyalPurple = Color(0xFF8A8AFF)
val ElectricCyan = Color(0xFF00CFFF)
val Gold = Color(0xFFFFD700)

// Supporting glass tones
val GlassWhite = Color(0x1AFFFFFF)      // translucent white for glass cards
val GlassBorder = Color(0x33FFFFFF)     // translucent border stroke
val TextPrimary = Color(0xFFF5F5FF)
val TextSecondary = Color(0xFFA8A8C0)
val ErrorRed = Color(0xFFFF5A5A)
