package com.mdultd.duo.share

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.util.Patterns
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.work.Data
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.mdultd.duo.download.DownloadWorker

/**
 * Transparent, no-UI activity that appears as a share target ("Share to DUO")
 * from WhatsApp, YouTube, Instagram, Chrome, etc. Extracts the shared URL,
 * enqueues a DownloadWorker job, then finishes immediately.
 */
class ShareReceiverActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        try {
            handleIncomingShare(intent)
        } catch (e: Exception) {
            Log.e("ShareReceiverActivity", "Failed to handle share intent", e)
            Toast.makeText(this, "DUO couldn't read that link.", Toast.LENGTH_SHORT).show()
        } finally {
            finish()
        }
    }

    private fun handleIncomingShare(intent: Intent?) {
        if (intent?.action != Intent.ACTION_SEND) return
        if (intent.type != "text/plain") return

        val sharedText = intent.getStringExtra(Intent.EXTRA_TEXT)
        val sourceApp = resolveSourceAppLabel()

        val url = extractFirstUrl(sharedText)
        if (url == null) {
            Toast.makeText(this, "No link found to save.", Toast.LENGTH_SHORT).show()
            return
        }

        enqueueDownload(url = url, sourceApp = sourceApp)
        Toast.makeText(this, "Saving to DUO Library…", Toast.LENGTH_SHORT).show()
    }

    private fun enqueueDownload(url: String, sourceApp: String) {
        val inputData = Data.Builder()
            .putString(DownloadWorker.KEY_URL, url)
            .putString(DownloadWorker.KEY_SOURCE_APP, sourceApp)
            .build()

        val request = OneTimeWorkRequestBuilder<DownloadWorker>()
            .setInputData(inputData)
            .build()

        WorkManager.getInstance(applicationContext).enqueue(request)
    }

    /** Best-effort guess at which app the share came from, for library labeling. */
    private fun resolveSourceAppLabel(): String {
        val referrerHost = referrer?.host ?: callingPackage
        return when {
            referrerHost?.contains("whatsapp") == true -> "WhatsApp"
            referrerHost?.contains("youtube") == true -> "YouTube"
            referrerHost?.contains("instagram") == true -> "Instagram"
            referrerHost?.contains("chrome") == true -> "Chrome"
            referrerHost?.contains("twitter") == true || referrerHost?.contains("x.com") == true -> "X"
            else -> "Shared Link"
        }
    }

    private fun extractFirstUrl(text: String?): String? {
        if (text.isNullOrBlank()) return null
        val matcher = Patterns.WEB_URL.matcher(text)
        return if (matcher.find()) {
            var url = text.substring(matcher.start(), matcher.end())
            if (!url.startsWith("http://") && !url.startsWith("https://")) {
                url = "https://$url"
            }
            url
        } else {
            null
        }
    }
}
