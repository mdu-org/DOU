package com.mdultd.duo.data

/**
 * A "Smart Pair" is a pre-configured duo of apps shown on the Home screen
 * as a glass card. Tapping the card launches both apps in split screen.
 */
data class SmartPair(
    val id: String,
    val appOneLabel: String,
    val appOnePackage: String,
    val appTwoLabel: String,
    val appTwoPackage: String,
    val isSponsored: Boolean = false,
    val sponsoredMessage: String? = null
)

object SmartPairsRepo {
    val defaultPairs = listOf(
        SmartPair(
            id = "wa_yt",
            appOneLabel = "WhatsApp",
            appOnePackage = "com.whatsapp",
            appTwoLabel = "YouTube",
            appTwoPackage = "com.google.android.youtube"
        ),
        SmartPair(
            id = "chrome_maps",
            appOneLabel = "Chrome",
            appOnePackage = "com.android.chrome",
            appTwoLabel = "Maps",
            appTwoPackage = "com.google.android.apps.maps"
        ),
        SmartPair(
            id = "ig_spotify",
            appOneLabel = "Instagram",
            appOnePackage = "com.instagram.android",
            appTwoLabel = "Spotify",
            appTwoPackage = "com.spotify.music"
        ),
        SmartPair(
            id = "sponsored_slot",
            appOneLabel = "Sponsored",
            appOnePackage = "",
            appTwoLabel = "",
            appTwoPackage = "",
            isSponsored = true,
            sponsoredMessage = "Discover a partner app"
        )
    )
}
