# DUO — Offline Internet by MDU LTD
**"1 Tap to Do 2 Things. Save the internet."**

A Jetpack Compose Android app (MVP) that lets you launch two apps together
(Smart Pairs / Custom Pairs) and save shared links for 100% offline access
(DUO Save), built with Kotlin, Material 3 glassmorphism, Room, WorkManager,
Firebase, and AdMob.

---

## 1. Requirements

- **Android Studio Hedgehog (2023.1.1)** or newer
- **JDK 17** (bundled with recent Android Studio installs)
- **Android SDK Platform 34** installed via SDK Manager
- A physical device or emulator running **Android 8.0 (API 26) or higher**
  (API 24+ needed for the `FLAG_ACTIVITY_LAUNCH_ADJACENT` split-screen hint)

---

## 2. Getting the project into Android Studio

1. Unzip the `DUO` project folder anywhere on your machine.
2. Open Android Studio → **File → Open** → select the `DUO` folder (the one
   containing `settings.gradle.kts`).
3. Let Gradle sync. First sync can take a few minutes while dependencies
   download (Compose, Room, WorkManager, Firebase, AdMob, Lottie).
4. If prompted, let Android Studio install any missing SDK/Build-Tools
   components.

---

## 3. No computer? Build the APK entirely from your phone

You don't need Android Studio to get a working APK. This project includes
a **GitHub Actions** workflow (`.github/workflows/build.yml`) that builds
the debug APK on GitHub's free cloud servers — you just need to get the
code into a GitHub repo from your phone, then download the finished APK.

1. Unzip this project on your phone (Android's Files app, or an app like
   ZArchiver, can extract a `.zip`).
2. Create a free account at [github.com](https://github.com) if you don't
   have one (works fine in a mobile browser).
3. Create a new **empty** repository (Menu → **+** → **New repository**;
   don't initialize it with a README, since this project already has one).
4. Get the code onto GitHub. Two options:
   - **Try first (may just work):** on the repo page, tap **Add file →
     Upload files**, then use the file picker to select the whole
     unzipped `DUO` folder. Some mobile browsers preserve the folder
     structure this way; some don't.
   - **If that fails (reliable fallback):** install **Termux** (from
     F-Droid, not the outdated Play Store version), then:
     ```
     pkg install git
     cd storage/downloads   # wherever you unzipped DUO
     cd DUO
     git init
     git branch -M main
     git add .
     git commit -m "DUO v1.0"
     git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
     git push -u origin main
     ```
     GitHub will prompt for a username + a **Personal Access Token**
     (Settings → Developer settings → Personal access tokens) instead of
     a password.
5. Once pushed, open the **Actions** tab on your repo. The "Build DUO
   APK" workflow starts automatically — wait a few minutes for the green
   checkmark.
6. Tap into the finished run, scroll to **Artifacts**, and download
   `duo-debug-apk` — it's a zip containing `app-debug.apk`.
7. Extract that zip, tap `app-debug.apk` to install. Android will prompt
   you to allow installs from that source (Files app / browser) the
   first time — approve it, then install.

No `google-services.json` needed for this path — the Google Services
(Firebase) Gradle plugin only applies itself if that file exists, so the
build succeeds without any Firebase setup. Firebase-dependent features
simply no-op at runtime (already wrapped in try/catch in
`DuoApplication.kt`).

Testing on your own real phone this way is actually better than an
emulator for the split-screen behavior described below.

---

## 4. Firebase setup (optional, only if you want real Firebase features)

The manifest and `build.gradle.kts` reference Firebase (Analytics,
Firestore, Auth) and the Google Services Gradle plugin. You need a real
`google-services.json` for the app to build/run cleanly:

1. Go to the [Firebase Console](https://console.firebase.google.com/) →
   **Add project**.
2. Add an Android app with package name **`com.mdultd.duo`**.
3. Download the generated `google-services.json`.
4. Place it at: `DUO/app/google-services.json`.

> Without this file, the `com.google.gms.google-services` plugin will fail
> the build. If you just want to try the UI without Firebase, you can
> temporarily remove the `id("com.google.gms.google-services")` line from
> `app/build.gradle.kts` and the Firebase dependencies — the rest of the
> app (Smart Pairs, DUO Save, Library, Custom Pairs, Settings) does not
> depend on Firebase at runtime in this MVP.

---

## 5. AdMob

The app ships with **Google's official TEST ad unit IDs** (both in
`AndroidManifest.xml` and `AdMobBanner.kt`), so ads will show immediately
as test ads — no AdMob account needed to run the app. Before publishing to
the Play Store:

1. Create a real AdMob app + banner ad unit at
   [apps.admob.com](https://apps.admob.com/).
2. Replace the `APPLICATION_ID` meta-data value in `AndroidManifest.xml`.
3. Replace `TEST_BANNER_AD_UNIT_ID` in `home/AdMobBanner.kt`.

---

## 6. Permissions this app requests

| Permission | Why |
|---|---|
| `INTERNET`, `ACCESS_NETWORK_STATE`, `ACCESS_WIFI_STATE` | Downloading shared links, checking WiFi for AutoSave |
| `QUERY_ALL_PACKAGES` | Listing installed apps for Smart Pairs / Custom Pairs |
| `POST_NOTIFICATIONS` | DownloadManager's completion notification (Android 13+) |
| `AD_ID` | AdMob banner ads |

`QUERY_ALL_PACKAGES` requires a Play Store declaration form if you publish
this app — see Google's
[package visibility policy](https://support.google.com/googleplay/android-developer/answer/10158779)
before release.

---

## 7. Running the app

1. Select a device/emulator (API 26+) in the toolbar.
2. Click **Run ▶**.
3. On first launch you'll see the 5-screen onboarding flow. Screen 3 lets
   you tap **"Try Split Screen Demo"**, which launches WhatsApp then
   YouTube — install both apps on your test device/emulator to see it work
   (the launcher gracefully no-ops with a toast if either is missing).
4. After onboarding, you land on **Home** with 4 Smart Pair glass cards,
   a **Build a Custom Pair** entry, and **My Library**.

### Testing DUO Save (the share receiver)

1. Open any app (Chrome, WhatsApp, etc.), share a link.
2. Choose **DUO** from the share sheet.
3. DUO silently downloads it in the background via WorkManager +
   DownloadManager and adds it to **My Library**, where you can reopen it
   fully offline.

---

## 8. Project structure

```
DUO/
├── app/
│   ├── src/main/java/com/mdultd/duo/
│   │   ├── DuoApplication.kt        # Firebase/AdMob init, schedules AutoSave
│   │   ├── MainActivity.kt          # NavHost: Onboarding → Home → Library/Settings
│   │   ├── onboarding/              # 5-page Lottie onboarding + split demo
│   │   ├── home/                    # Smart Pair cards + AdMob banner
│   │   ├── split/                   # SplitScreenLauncher (ActivityOptions)
│   │   ├── share/                   # ShareReceiverActivity (ACTION_SEND)
│   │   ├── download/                # DownloadWorker + AutoSaveWorker
│   │   ├── library/                 # MyLibraryScreen (Room, offline)
│   │   ├── custompair/              # Installed-app picker → Custom Pair
│   │   ├── settings/                # Data saved counter, theme switch, about
│   │   ├── data/                    # Room entities/DAOs/DB, DataStore, SmartPair
│   │   └── ui/theme/                # Color.kt, Theme.kt, Type.kt, GlassCard.kt
│   └── src/main/AndroidManifest.xml
├── build.gradle.kts
├── settings.gradle.kts
└── README.md
```

---

## 9. Known MVP limitations (by design, documented in code comments)

- **True OS-level split screen** cannot be forced by a third-party app on
  stock Android — there's no public API for it. `SplitScreenLauncher`
  launches both apps with `FLAG_ACTIVITY_LAUNCH_ADJACENT`, which tiles
  automatically on large-screen/foldable/ChromeOS devices; on regular
  phones it opens app two on top, and the onboarding screen 3 demo teaches
  the user the native "drag from Recents" gesture to snap them together.
- Room DB uses `fallbackToDestructiveMigration()` for the MVP — replace
  with real `Migration` objects before shipping schema changes.
- `google-services.json` must be supplied by you (see section 3).

---

© 2026 MDU LTD
